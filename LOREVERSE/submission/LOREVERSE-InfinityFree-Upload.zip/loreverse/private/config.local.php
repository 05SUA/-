<?php

declare(strict_types=1);

$source = dirname(__DIR__, 2) . '/loreverse-stage01/private/config.local.php';
$existing = is_file($source) ? require $source : [];
$allowed = array_flip([
    'DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD',
    'GEMINI_API_KEY', 'GEMINI_MODEL', 'HERO_VIDEO_URL', 'AI_DAILY_LIMIT',
]);

return [
    'APP_ENV' => 'production',
    'APP_BASE_URL' => 'https://loreverse.42web.io/loreverse/public',
] + array_intersect_key(is_array($existing) ? $existing : [], $allowed);
