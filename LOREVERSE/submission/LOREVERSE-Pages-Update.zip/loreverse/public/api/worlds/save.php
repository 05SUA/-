<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/world-api.php';
loreverseWorldApi('save');
